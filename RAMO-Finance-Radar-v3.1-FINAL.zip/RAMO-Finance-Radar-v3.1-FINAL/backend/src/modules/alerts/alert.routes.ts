import { Router } from "express";
import {
  createAlertController,
  deleteAlertController,
  getAlertByIdController,
  listAlertsController,
  updateAlertController,
  updateAlertStatusController
} from "./alert.controller";
import { requireTelegramAuth } from "../../middleware/telegram-auth";

export const alertRoutes = Router();

alertRoutes.use("/api/alerts", requireTelegramAuth);

alertRoutes.get("/api/alerts", listAlertsController);
alertRoutes.post("/api/alerts", createAlertController);
alertRoutes.get("/api/alerts/:id", getAlertByIdController);
alertRoutes.patch("/api/alerts/:id", updateAlertController);
alertRoutes.patch("/api/alerts/:id/status", updateAlertStatusController);
alertRoutes.delete("/api/alerts/:id", deleteAlertController);
